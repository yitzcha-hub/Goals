import React from 'react';
import PaymentSuccess from '@/components/PaymentSuccess';

const PaymentSuccessPage: React.FC = () => {
  return <PaymentSuccess />;
};

export default PaymentSuccessPage;