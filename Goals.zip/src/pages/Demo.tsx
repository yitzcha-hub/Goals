import DemoLayout from '@/components/DemoLayout';

const Demo = () => {
  return <DemoLayout />;
};

export default Demo;
